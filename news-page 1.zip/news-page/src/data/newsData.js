export const latestLaunches = [
    {
      title: "Upcoming Cars in India, New Car Launches 2025 | Autocar India",
      link: "https://www.autocarindia.com/upcoming-cars",
      snippet: "Apr 7, 2025 ... New Car Launch in India 2025 - What to Expect \u00b7 Maruti Suzuki e Vitara \u00b7 Toyota Urban Cruiser EV \u00b7 Skoda Octavia \u00b7 Volkswagen Golf GTI \u00b7 Tata Sierra \u00b7 Tata\u00a0...",
      image: "https://img.autocarindia.com/model/uploads/modelimages/Tata-Altroz-Facelift-130520251139.jpg",
      publish_date: "2025-05-22"
    },
    {
      title: "Nissan Teases Two New Upcoming Cars, Launching This Year",
      link: "https://www.ndtv.com/auto/nissan-teases-two-new-upcoming-cars-launching-this-year-8326933",
      snippet: "May 4, 2025 ... The upcoming Nissan SUV will closely compete with other cars in the Indian market, like- Hyundai Creta, Maruti Suzuki Grand Vitara, Honda Elevate and more. Also\u00a0...",
      image: "https://c.ndtvimg.com/2025-05/6lk4copk_nissan_625x300_04_May_25.jpg?im=FitAndFill,algorithm=dnn,width=1200,height=800",
      publish_date: "2025-05-22"
    },
    {
      title: "Top 5 Car Launches In May 2025",
      link: "https://www.ndtv.com/auto/top-5-car-launches-in-may-2025-8296238",
      snippet: "May 1, 2025 ... Here's a lowdown on the top 5 car launches that will take place in May 2025. These include the likes of the Kia Carens facelift, VW Golf GTI,\u00a0...",
      image: "https://c.ndtvimg.com/2025-01/23tpgqd8_mgcyberster_625x300_06_January_25.jpg?im=FeatureCrop,algorithm=dnn,width=1200,height=800",
      publish_date: "2025-05-22"
    },
    {
      title: "Upcoming car and SUV launches in April 2025 | Autocar India",
      link: "https://www.autocarindia.com/car-news/upcoming-car-and-suv-launches-in-april-2025-434961",
      snippet: "Mar 31, 2025 ... Upcoming car and SUV launches in April 2025 \u00b7 Volkswagen Tiguan R Line \u00b7 MG Cyberster \u00b7 Kia Carens facelift \u00b7 Skoda Kodiaq \u00b7 Tata Curvv Dark Edition \u00b7 Citroen\u00a0...",
      image: "https://img.autocarindia.com/ExtraImages/20250327051851_Upcoming%20Launches%20in%20April.jpg?w=700&c=1",
      publish_date: "2025-05-22"
    },
    {
      title: "New car launches in February, Kia Syros, Audi RS Q8 Performance ...",
      link: "https://www.autocarindia.com/car-news/new-car-launches-in-february-2025-434409",
      snippet: "Jan 31, 2025 ... Upcoming cars in February 2025 include Kia Syros, Audi RS Q8 Performance and Aston Martin Vanquish.",
      image: "https://img.autocarindia.com/ExtraImages/20250130042158_Upcoming%20cars%20and%20SUV%20in%20February%202025.jpg?w=700&c=1",
      publish_date: "2025-05-22"
    },
    {
      title: "Which upcoming cars in 2025 are you most excited about | Team-BHP",
      link: "https://www.team-bhp.com/news/which-upcoming-cars-2025-are-you-most-excited-about",
      snippet: "Mar 11, 2025 ... 1) Skoda Octavia Diesel and VRS: I am eagerly waiting for these cars to hit the Indian shores. Even though they are CBU and priced insanely, I would love for\u00a0...",
      image: "https://www.team-bhp.com/themes/bhp/images/teambhp-og-image-fb.jpg",
      publish_date: "2025-05-22"
    },
    {
      title: "BYD's First Mini EV Spotted- Will the Kei Car Launch In India?",
      link: "https://www.ndtv.com/auto/byds-first-mini-ev-spotted-will-the-kei-car-launch-in-india-8428703",
      snippet: "6 days ago ... Before any official announcement, it has been spotted testing on public roads, giving us a glimpse of what the upcoming model will look like. Kei cars are known\u00a0...",
      image: "https://c.ndtvimg.com/2025-05/uf12js24_byd-mini-car-spy_625x300_16_May_25.jpg?im=FitAndFill,algorithm=dnn,width=1200,height=800",
      publish_date: "2025-05-22"
    },
    {
      title: "Hyundai India To Launch 26 New Cars By 2030 To Regain Top Spot",
      link: "https://www.ndtv.com/auto/hyundai-india-to-launch-26-new-cars-by-2030-to-regain-top-spot-8430181",
      snippet: "6 days ago ... Between FY'25 to FY'26, Hyundai Motor India Limited will launch 26 cars in the country. The announcement was made along with the brand's Q4 earnings.",
      image: "https://c.ndtvimg.com/2024-06/lmcdc6hg_hyundai-logo_625x300_15_June_24.jpeg?im=FeatureCrop,algorithm=dnn,width=1200,height=800",
      publish_date: "2025-05-22"
    },
    {
      title: "MG To Launch Three New Cars In India: Cyberster Majestor M9",
      link: "https://www.ndtv.com/auto/mg-to-launch-three-new-cars-in-india-cyberster-majestor-m9-7967440",
      snippet: "Mar 20, 2025 ... With a top speed of 180 km/h, the M9 proves to be a good blend of elegance and power. Advertisement. MG M9 is expected to be launched in India in March 2025\u00a0...",
      image: "https://c.ndtvimg.com/2024-12/gn5gag4o_mg-cyberster_625x300_10_December_24.jpg?im=FaceCrop,algorithm=dnn,width=1200,height=800",
      publish_date: "2025-05-22"
    },
    {
      title: "Upcoming car launches and unveils in May 2025 | Autocar India",
      link: "https://www.autocarindia.com/car-news/upcoming-car-launches-and-unveils-in-may-2025-435235",
      snippet: "Apr 30, 2025 ... Upcoming car launches and unveils in May 2025 \u00b7 New Kia Carens \u2013 May 8 \u00b7 Tata Altroz facelift \u2013 late May \u00b7 Volkswagen Golf GTi \u2013 late May \u00b7 MG Windsor with a\u00a0...",
      image: "https://img.autocarindia.com/ExtraImages/20250430015441_Upcoming%20Car%20Launches%20_1_.jpg?w=700&c=1",
      publish_date: "2025-05-22"
    },
    {
        title: "Auto News: Latest Automobiles and Auto Industry News | Car, Bike ...",
        link: "https://www.livemint.com/auto-news",
        snippet: "Auto News \u00b7 Tata Motors is all set to reveal the extensively revamped Altroz facelift on May 22, \u00b7 Honda Motorcycles and Scooters India (HMSI) has officially\u00a0...",
        image: "https://www.livemint.com/lm-img/newschemalogo.png",
        publish_date: "2025-05-22"
      },
      {
        title: "ET Auto: Auto News | Latest Automobiles & Auto Industry Information ...",
        link: "https://auto.economictimes.indiatimes.com/",
        snippet: "Find the latest automobile Auto Insight, News & Articles from all top sources for the Indian Auto industry on ET Auto.",
        image: "https://st.etb2bimg.com/Themes/Release/images/respective/etauto-logo-400x400.jpg",
        publish_date: "2025-05-22"
      }
  ];
  
  export const aiInnovations = [
    {
      title: "AI - Automotive News",
      link: "https://www.autonews.com/technology/ai/",
      snippet: "As the automotive industry evolves with the latest AI technology, Auto News keeps you up-to-date with insights and breaking news.",
      image: "https://www.autonews.com/resizer/v2/5FM2H4KV7BHBRJOM5O2RTSPETE.jpg?smart=true&auth=6e1ee340da2da8bf14dc14219d8f5a4b2aeef782d80ee520007cddcdcea6c22d&width=2157&height=1213",
      publish_date: "2025-05-22"
    },
    {
      title: "GM using AI to help dealers order inventory - Automotive News",
      link: "https://canada.autonews.com/general-motors/an-general-motors-retail-ordering-ai-0225/",
      snippet: "Feb 25, 2025 ... A new recommendation engine GM is rolling out to its North American dealerships is designed to help retailers narrow the myriad\u00a0...",
      image: "https://cloudfront-us-east-1.images.arcpublishing.com/crain/YYNJ2SXADRHC3LBEM5H2QMTTAE.png",
      publish_date: "2025-02-25T15:15:56.114Z"
    },
    {
      title: "Volvo's latest safety innovation relies on new AI technique ...",
      link: "https://www.autonews.com/technology/an-nvidia-gtc-volvo-ai-0319/",
      snippet: "Mar 19, 2025 ... Seven of Automotive News' 100 Leading Women in the North American Auto Industry share lessons on leadership, their management style, advocating\u00a0...",
      image: "https://cloudfront-us-east-1.images.arcpublishing.com/crain/R56E3JK475AEDMEILDKY2D7DBA.png",
      publish_date: "2025-03-19T07:00:00Z"
    },
    {
      title: "Aptiv Wins Automotive News PACE Pilot Award for Innovative AI/ML ...",
      link: "https://www.aptiv.com/en/newsroom/article/aptiv-wins-automotive-news-pace-pilot-award-for-innovative-ai-ml-autonomous-driving-technologies",
      snippet: "Apr 16, 2025 ... It was named a 2025 Automotive News PACE Pilot Innovation to Watch for its groundbreaking Aptiv Embedded AI Modules: Radar AI/ML and ML Behavior Planner.",
      image: "https://www.aptiv.com/images/default-source/news-releases/pace-awards-visuals-v4-1200x627.jpg?sfvrsn=3d938b37_1",
      publish_date: "2025-05-22"
    },
    {
      title: "Automotive News | Car, EV & Dealership News - Automotive News",
      link: "https://www.autonews.com/",
      snippet: "... ai/. Latest News. View All \u00b7 Retail \u00b7 Daily 5 report for May 21: U.S. dealers more concerned about tariffs in Q2, Cox survey says \u00b7 Executives \u00b7 Ousted Reynolds\u00a0...",
      image: "https://cloudfront-us-east-1.images.arcpublishing.com/sandbox.crain/EN2CH5O4MVEWVGZZ4JQ6RRENIM.jpg",
      publish_date: "2025-05-22"
    },
    {
      title: "CDK Global - Automotive News",
      link: "https://arcxp-prod.autonews.com/resource_center/CDK/",
      snippet: "The AI in Automotive: Insights and Innovations 2024 Study took feedback from ... Latest News. Stellantis delays electrified pickup trucks at Sterling\u00a0...",
      image: null,
      publish_date: "2025-05-22"
    },
    {
      title: "Impel teams with FordDirect to expand its AI marketing tech ...",
      link: "https://www.autonews.com/news/an-impel-partners-with-ford-over-ai-tech/",
      snippet: "Jan 22, 2025 ... Retail automotive software company Impel sealed a new partnership with FordDirect to bring its conversational AI to more than 3,000 Ford\u00a0...",
      image: "https://cloudfront-us-east-1.images.arcpublishing.com/crain/UTBNYLV33VAYJB7OZVXZC7SNQY.jpg",
      publish_date: "2025-01-22T15:00:00Z"
    },
    {
      title: "finaldie/auto-news: A personal news aggregator to pull ... - GitHub",
      link: "https://github.com/finaldie/auto-news",
      snippet: "The ultimate personal productivity content aggregator: Designed to effortlessly navigate and maximize your efficiency in the AI era. ... helm-chart/0.9.15 Latest.",
      image: "https://opengraph.githubassets.com/4cfc8b569079e17f7586d7ebe12664feb544b195a8332eb1a881a1cfa2ebf779/finaldie/auto-news",
      publish_date: "2025-05-22"
    },
    {
      title: "GM's first chief AI officer worked at Cisco, Google - Automotive News",
      link: "https://www.autonews.com/general-motors/an-general-motors-chief-ai-officer-0303/",
      snippet: "Mar 3, 2025 ... Barak Turovsky will serve as GM's chief AI officer, a new role. He reports to Dave Richardson, senior vice president of software and\u00a0...",
      image: "https://cloudfront-us-east-1.images.arcpublishing.com/crain/4QG2ZNGVBNEYXJJWKRLQGWKM4Y.png",
      publish_date: "2025-03-03T20:55:16.581Z"
    },
    {
      title: "NVIDIA Expands Automotive Ecosystem With Physical AI | NVIDIA ...",
      link: "https://blogs.nvidia.com/blog/auto-ecosystem-physical-ai/",
      snippet: "Mar 18, 2025 ... At GTC, Cerence AI is showcasing Cerence xUI, its new LLM-based AI ... Learn more about NVIDIA's latest automotive news by watching the\u00a0...",
      image: "https://blogs.nvidia.com/wp-content/uploads/2025/03/automotive-corp-blog-ecosystem-1280x680-1.jpg",
      publish_date: "2025-03-18T19:30:02+00:00"
    },
    {
        title: "Volvo's latest safety innovation relies on new AI technique ...",
        link: "https://www.autonews.com/technology/an-nvidia-gtc-volvo-ai-0319/",
        snippet: "Mar 19, 2025 ... Seven of Automotive News' 100 Leading Women in the North American Auto Industry share lessons on leadership, their management style, advocating\u00a0...",
        image: "https://cloudfront-us-east-1.images.arcpublishing.com/crain/R56E3JK475AEDMEILDKY2D7DBA.png",
        publish_date: "2025-03-19T07:00:00Z"
      },
      {
        title: "Aptiv Wins Automotive News PACE Pilot Award for Innovative AI/ML ...",
        link: "https://www.aptiv.com/en/newsroom/article/aptiv-wins-automotive-news-pace-pilot-award-for-innovative-ai-ml-autonomous-driving-technologies",
        snippet: "Apr 16, 2025 ... It was named a 2025 Automotive News PACE Pilot Innovation to Watch for its groundbreaking Aptiv Embedded AI Modules: Radar AI/ML and ML Behavior Planner.",
        image: "https://www.aptiv.com/images/default-source/news-releases/pace-awards-visuals-v4-1200x627.jpg?sfvrsn=3d938b37_1",
        publish_date: "2025-05-22"
      }
  ];
  
  export const trending = [
    {
      title: "Automotive News | Car, EV & Dealership News - Automotive News",
      link: "https://www.autonews.com/",
      snippet: "... Latest News. View All \u00b7 Retail \u00b7 Daily 5 report for May 21: U.S. dealers more concerned about tariffs in Q2, Cox survey says \u00b7 Executives \u00b7 Ousted Reynolds and\u00a0...",
      image: "https://cloudfront-us-east-1.images.arcpublishing.com/sandbox.crain/EN2CH5O4MVEWVGZZ4JQ6RRENIM.jpg",
      publish_date: "2025-05-22"
    },
    {
      title: "Automotive Industry Latest News, Auto sector India Update ...",
      link: "https://m.economictimes.com/industry/auto",
      snippet: "Auto Components \u00b7 Automotive component sector likely to clock 7-9% revenue growth in FY26: Crisil \u00b7 Wheels India earmarks Rs 250 crore as capital expenditure\u00a0...",
      image: "https://m.economictimes.com/thumb/msid-65498029,width-640,resizemode-4/et-logo.jpg",
      publish_date: "2025-05-22"
    },
    {
      title: "Automobile News | Auto Industry News | Auto Sector News",
      link: "https://auto.economictimes.indiatimes.com/news",
      snippet: "Honda Motorcycle to expand Gujarat plant with \u20b9920 cr investment in fourth production line \u00b7 FTA with UK lays the road for JLR to double India sales: CCO \u00b7 Who is\u00a0...",
      image: "https://st.etb2bimg.com/Themes/Release/images/responsive/etauto-logo-400x400.jpg",
      publish_date: "2025-05-22"
    },
    {
      title: "Auto News: Latest Automobiles and Auto Industry News | Car, Bike ...",
      link: "https://www.livemint.com/auto-news",
      snippet: "Auto News \u00b7 Tata Motors is all set to reveal the extensively revamped Altroz facelift on May 22, \u00b7 Honda Motorcycles and Scooters India (HMSI) has officially\u00a0...",
      image: "https://www.livemint.com/lm-img/newschemalogo.png",
      publish_date: "2025-05-22"
    },
    {
      title: "ET Auto: Auto News | Latest Automobiles & Auto Industry Information ...",
      link: "https://auto.economictimes.indiatimes.com/",
      snippet: "Find the latest automobile Auto Insight, News & Articles from all top sources for the Indian Auto industry on ET Auto.",
      image: "https://st.etb2bimg.com/Themes/Release/images/respective/etauto-logo-400x400.jpg",
      publish_date: "2025-05-22"
    },
    {
      title: "MotorTrend: New Cars - Car News and Expert Reviews",
      link: "https://www.motortrend.com/",
      snippet: "The Latest From MotorTrend \u00b7 2026 Chevrolet Silverado EV Trail Boss First Look: An Electric Rough Rider \u00b7 2026 Honda HR-V: Not Much Changes on This Small SUV, For\u00a0...",
      image: "https://www.motortrend.com/files/682cd84739615000089431bf/2026toyotarav4hybridsuvcrossover-13.jpg?w=768&width=768&q=75&format=webp",
      publish_date: "2025-05-22"
    },
    {
      title: "Car News, Auto News India - CarWale",
      link: "https://www.carwale.com/news/",
      snippet: "Check out Latest Car News, Auto Launch Updates and Expert Reviews on Indian Car Industry at CarWale.",
      image: "https://imgd.aeplcdn.com/642x336/n/cw/ec/199863/altroz-facelift-exterior-front-view-4.jpeg?isig=0&isig=0&wm=1&q=80",
      publish_date: "2025-05-22"
    },
    {
      title: "Autocar India: Latest Car News & Reviews - Upcoming Bikes & Cars ...",
      link: "https://www.autocarindia.com/",
      snippet: "News, Cars, Bikes, Motorsports, Industry, Marketplace, Reviews, Car First drive / Reviews, Comparisons, Video reviews, Long-term reviews",
      image: "https://img.autocarindia.com/Features/Most-affordable-SUVs-in-India-under-Rs-10-lakh.jpg?w=800&h=533&q=70&c=1",
      publish_date: "2025-05-22"
    },
    {
      title: "Auto News, Latest Car News, Upcoming Car and Bike, New ...",
      link: "https://www.indiatoday.in/auto",
      snippet: "Nissan Micra EV unveiled with claimed range of 408km ... Nissan unveiled the new Micra EV, an electric compact car offering up to 408km range. The Micra EV will\u00a0...",
      image: "https://akm-img-a-in.tosshub.com/indiatoday/images/category_management/201712/auto-40x35.png?VersionId=u.4kfUYpnTGjSwF0x_Oiteu_0PnjCt9P",
      publish_date: "2025-05-22"
    },
    {
      title: "Auto News: Latest Car and Bike News Today, Auto News in India",
      link: "https://auto.hindustantimes.com/auto/news",
      snippet: "Auto News \u00b7 Royal Enfield Urban Outerwear riding gear launched for everyday city riders \u00b7 Auto recap, May 20: Volkswagen Golf GTI launch date, Renault announces\u00a0...",
      image: "https://images.hindustantimes.com/auto/img/static/htautologo-v5.svg",
      publish_date: "2025-05-22"
    }
  ];
  
  export const llmInsights = {
    summary: "The car market in India is buzzing with anticipation as several promising models are set to launch in 2025. Key automakers like Maruti Suzuki, Toyota, Skoda, Volkswagen, Tata, Nissan, Kia, Audi, and MG are gearing up to introduce new vehicles that cater to diverse consumer needs, ranging from electric vehicles (EVs) to performance-oriented models. Maruti Suzuki plans to unveil the e Vitara, while Toyota is set to launch the Urban Cruiser EV, both emphasizing the growing trend towards electrification. Skoda and Volkswagen are also in the spotlight with the Octavia and Golf GTI, respectively, reflecting a blend of style and performance. Tata is making waves with the Sierra and Curvv Dark Edition, highlighting a mix of traditional and modern design elements.",
    recentCarLaunches: [
      "Maruti Suzuki e Vitara",
      "Toyota Urban Cruiser EV",
      "Skoda Octavia",
      "Volkswagen Golf GTI",
      "Tata Sierra",
      "Tata Curvv Dark Edition",
      "Nissan SUV models",
      "Kia Carens facelift",
      "MG Cyberster",
      "MG Majestor M9",
      "Audi RS Q8 Performance",
      "Aston Martin Vanquish",
      "BYD Mini EV",
      "Hyundai's lineup of 26 new cars by 2030"
    ],
    additionalInformation: [
      {
        description: "Detailed list of upcoming cars in India in 2025",
        link: "https://www.autocarindia.com/upcoming-cars"
      },
      {
        description: "Insights into Nissan's upcoming SUV launches",
        link: "https://www.ndtv.com/auto/nissan-teases-two-new-upcoming-cars-launching-this-year-8326933"
      },
      {
        description: "Overview of top car launches in May 2025",
        link: "https://www.ndtv.com/auto/top-5-car-launches-in-may-2025-8296238"
      },
      {
        description: "Upcoming car and SUV launches in April 2025",
        link: "https://www.autocarindia.com/car-news/upcoming-car-and-suv-launches-in-april-2025-434961"
      },
      {
        description: "Information on Hyundai's ambitious plans to launch 26 new cars by 2030",
        link: "https://www.ndtv.com/auto/hyundai-india-to-launch-26-new-cars-by-2030-to-regain-top-spot-8430181"
      }
    ]
  };