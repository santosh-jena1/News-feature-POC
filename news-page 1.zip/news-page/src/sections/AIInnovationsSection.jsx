import React, { useState } from 'react';
import { Box, Typography, Grid, Button } from '@mui/material';
import NewsCard from '../components/NewsCard';
import { aiInnovations } from '../data/newsData';

const AIInnovationsSection = () => {
  const [startIndex, setStartIndex] = useState(0);
  const cardsPerPage = 4; // Show 4 cards at a time

  // Calculate the visible cards (4 at a time)
  const visibleCards = aiInnovations?.length > 0 
    ? aiInnovations.slice(startIndex, startIndex + cardsPerPage)
    : [];

  // Handle "Previous" button click
  const handlePrevious = () => {
    const prevIndex = startIndex - cardsPerPage;
    if (prevIndex < 0) {
      // Loop to the last set of cards
      const totalCards = aiInnovations.length;
      const lastFullSet = Math.floor((totalCards - 1) / cardsPerPage) * cardsPerPage;
      setStartIndex(lastFullSet);
    } else {
      setStartIndex(prevIndex);
    }
  };

  // Handle "Next" button click
  const handleNext = () => {
    const nextIndex = startIndex + cardsPerPage;
    if (nextIndex >= aiInnovations.length) {
      setStartIndex(0); 
    } else {
      setStartIndex(nextIndex); // Show next set of cards
    }
  };

  return (
    <Box id="ai-innovations" sx={{ py: 4, px: { xs: 2, sm: 0 }, mb: 2 }}>
      <Typography
        variant="h4"
        className="font-serif"
        sx={{ color: '#1E40AF', fontWeight: 'bold', mb: 2, borderBottom: '2px solid #2563EB', pb: 1 }}
      >
        AI Innovations in Automotive
      </Typography>
      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        <Grid
          container
          spacing={3}
          sx={{ 
            display: 'grid', 
            gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, 1fr)' }, 
            gap: { xs: '1.5rem', sm: '24px' } 
          }}
        >
          {visibleCards.length > 0 ? (
            visibleCards.map((article, index) => (
              <Grid item xs={12} sm={6} key={index} sx={{ display: 'flex' }}>
                <NewsCard article={article} />
              </Grid>
            ))
          ) : (
            <Typography
              variant="body1"
              sx={{ color: '#374151', fontFamily: '"Roboto", sans-serif', gridColumn: 'span 2' }}
            >
              No AI innovations available.
            </Typography>
          )}
        </Grid>
        {aiInnovations?.length > cardsPerPage && (
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 2 }}>
            <Button
              onClick={handlePrevious}
              sx={{
                color: '#1E40AF',
                textTransform: 'none',
                fontFamily: '"Roboto", sans-serif',
                fontWeight: 'medium',
                '&:hover': {
                  backgroundColor: '#E5E7EB',
                },
              }}
            >
              Previous
            </Button>
            <Button
              onClick={handleNext}
              sx={{
                color: '#1E40AF',
                textTransform: 'none',
                fontFamily: '"Roboto", sans-serif',
                fontWeight: 'medium',
                '&:hover': {
                  backgroundColor: '#E5E7EB',
                },
              }}
            >
              Next
            </Button>
          </Box>
        )}
      </Box>
    </Box>
  );
};

export default AIInnovationsSection;