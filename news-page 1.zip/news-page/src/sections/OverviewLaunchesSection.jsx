import React, { useState, useEffect } from 'react';
import { Box, Typography, List, ListItem, ListItemText, Card, CardContent, Fade, CircularProgress } from '@mui/material';
import { llmInsights } from '../data/newsData';

const OverviewLaunchesSection = () => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [displayedText, setDisplayedText] = useState('');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showCards, setShowCards] = useState(false);

  const carLaunches = llmInsights?.recentCarLaunches || [];
  const additionalInfo = llmInsights?.additionalInformation || [];
  const summary = llmInsights?.summary || 'No summary available.';

  // Typewriter effect for summary
  useEffect(() => {
    setIsLoaded(true);
    const timer = setInterval(() => {
      if (currentIndex < summary.length) {
        setDisplayedText((prev) => prev + summary[currentIndex]);
        setCurrentIndex((prev) => prev + 1);
      } else {
        clearInterval(timer);
        setTimeout(() => setShowCards(true), 300);
      }
    }, 25);
    return () => clearInterval(timer);
  }, [currentIndex, summary]);

  return (
    <Box
      id="overview-launches"
      sx={{
        py: 8,
        px: { xs: 3, sm: 5 },
        mb: 1,
        background: 'linear-gradient(180deg, #E6F0FA 0%, #FFFFFF 100%)',
        borderRadius: 4,
        boxShadow: '0 4px 20px rgba(0, 0, 0, 0.05)',
      }}
    >
      {/* Header */}
      <Typography
        variant="h3"
        className="font-serif"
        sx={{
          color: '#1E3A8A',
          fontWeight: 700,
          mb: 4,
          textAlign: 'center',
          letterSpacing: '0.5px',
          background: 'linear-gradient(90deg, #2563EB, #7C3AED)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          position: 'relative',
          '&:after': {
            content: '""',
            position: 'absolute',
            bottom: '-8px',
            left: '50%',
            transform: 'translateX(-50%)',
            width: '100px',
            height: '4px',
            background: 'linear-gradient(90deg, #2563EB, #7C3AED)',
            borderRadius: '2px',
          },
        }}
      >
        Upcoming Car Launches
      </Typography>

      {/* Loading Animation */}
      <Fade in={!isLoaded} timeout={500} unmountOnExit>
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '250px' }}>
          <CircularProgress
            sx={{
              color: '#2563EB',
              animation: 'pulse 1.5s ease-in-out infinite',
              '@keyframes pulse': {
                '0%': { transform: 'scale(1)', opacity: 1 },
                '50%': { transform: 'scale(1.3)', opacity: 0.6 },
                '100%': { transform: 'scale(1)', opacity: 1 },
              },
            }}
            size={60}
          />
        </Box>
      </Fade>

      {/* Content */}
      <Fade in={isLoaded} timeout={1000}>
        <Box>
          {/* Summary Section */}
          <Box
            sx={{
              mb: 5,
              px: { xs: 2, sm: 4 },
              py: 3,
              backgroundColor: '#FFFFFF',
              borderRadius: 3,
              boxShadow: '0 4px 12px rgba(0, 0, 0, 0.08)',
              borderLeft: '4px solid #2563EB',
            }}
          >
            <Typography
              variant="body1"
              sx={{
                color: '#1F2937',
                fontFamily: '"Roboto", sans-serif',
                lineHeight: 1.7,
                fontSize: { xs: '1rem', sm: '1.1rem' },
              }}
            >
              {displayedText}
            </Typography>
          </Box>

          {/* Side-by-Side Sections */}
          <Box
            sx={{
              display: 'flex',
              flexDirection: { xs: 'column', md: 'row' },
              gap: 4,
            }}
          >
            {/* Recent Car Launches Section */}
            <Fade in={showCards} timeout={1200}>
              <Box sx={{ flex: 1 }}>
                <Card
                  sx={{
                    background: 'linear-gradient(145deg, #FFFFFF, #F3F4F6)',
                    boxShadow: '0 6px 20px rgba(0, 0, 0, 0.1)',
                    borderRadius: 4,
                    border: '1px solid rgba(37, 99, 235, 0.1)',
                    transition: 'transform 0.4s ease, box-shadow 0.4s ease',
                    '&:hover': {
                      transform: 'translateY(-8px)',
                      boxShadow: '0 8px 24px rgba(0, 0, 0, 0.15)',
                    },
                    minHeight: '400px',
                    overflow: 'hidden',
                  }}
                >
                  <CardContent sx={{ p: 4, height: '100%', display: 'flex', flexDirection: 'column' }}>
                    <Typography
                      variant="h5"
                      sx={{
                        color: '#1E40AF',
                        fontWeight: 600,
                        mb: 3,
                        fontFamily: '"Poppins", sans-serif',
                      }}
                    >
                      Recent Car Launches
                    </Typography>
                    <Box
                      sx={{
                        flexGrow: 1,
                        overflowY: 'auto',
                        maxHeight: '280px',
                        '&::-webkit-scrollbar': {
                          width: '4px',
                          backgroundColor: 'transparent',
                        },
                        '&::-webkit-scrollbar-track': {
                          background: 'rgba(229, 231, 235, 0.3)',
                          borderRadius: '8px',
                          margin: '8px 0',
                        },
                        '&::-webkit-scrollbar-thumb': {
                          background: 'rgba(37, 99, 235, 0.5)',
                          borderRadius: '8px',
                          transition: 'background 0.3s ease',
                        },
                        '&::-webkit-scrollbar-thumb:hover': {
                          background: 'rgba(37, 99, 235, 0.8)',
                        },
                        // Firefox scrollbar styling
                        scrollbarWidth: 'thin',
                        scrollbarColor: 'rgba(37, 99, 235, 0.5) rgba(229, 231, 235, 0.3)',
                      }}
                    >
                      <List sx={{ pl: 0 }}>
                        {carLaunches.length > 0 ? (
                          carLaunches.map((car, index) => (
                            <ListItem
                              key={index}
                              sx={{
                                py: 1.5,
                                borderBottom: '1px solid #E5E7EB',
                                '&:last-child': { borderBottom: 'none' },
                                transition: 'background-color 0.3s, transform 0.3s',
                                '&:hover': {
                                  backgroundColor: '#EFF6FF',
                                  transform: 'translateX(5px)',
                                },
                              }}
                            >
                              <ListItemText
                                primary={car}
                                primaryTypographyProps={{
                                  variant: 'body1',
                                  sx: {
                                    color: '#1F2937',
                                    fontFamily: '"Open Sans", sans-serif',
                                    fontSize: '1rem',
                                  },
                                }}
                              />
                            </ListItem>
                          ))
                        ) : (
                          <ListItem>
                            <ListItemText
                              primary="No car launches available."
                              primaryTypographyProps={{
                                sx: { color: '#6B7280', fontStyle: 'italic' },
                              }}
                            />
                          </ListItem>
                        )}
                      </List>
                    </Box>
                  </CardContent>
                </Card>
              </Box>
            </Fade>

            {/* Additional Information Section */}
            <Fade in={showCards} timeout={1500}>
              <Box sx={{ flex: 1 }}>
                <Card
                  sx={{
                    background: 'linear-gradient(145deg, #FFFFFF, #F3F4F6)',
                    boxShadow: '0 6px 20px rgba(0, 0, 0, 0.1)',
                    borderRadius: 4,
                    border: '1px solid rgba(37, 99, 235, 0.1)',
                    transition: 'transform 0.4s ease, box-shadow 0.4s ease',
                    '&:hover': {
                      transform: 'translateY(-8px)',
                      boxShadow: '0 8px 24px rgba(0, 0, 0, 0.15)',
                    },
                    minHeight: '400px',
                    overflow: 'hidden',
                  }}
                >
                  <CardContent sx={{ p: 4, height: '100%', display: 'flex', flexDirection: 'column' }}>
                    <Typography
                      variant="h5"
                      sx={{
                        color: '#1E40AF',
                        fontWeight: 600,
                        mb: 3,
                        fontFamily: '"Poppins", sans-serif',
                      }}
                    >
                      Additional Information
                    </Typography>
                    <Box
                      sx={{
                        flexGrow: 1,
                        overflowY: 'auto',
                        maxHeight: '280px',
                        display: 'flex',
                        flexDirection: 'column',
                        gap: 2,
                        '&::-webkit-scrollbar': {
                          width: '4px',
                          backgroundColor: 'transparent',
                        },
                        '&::-webkit-scrollbar-track': {
                          background: 'rgba(229, 231, 235, 0.3)',
                          borderRadius: '8px',
                          margin: '8px 0',
                        },
                        '&::-webkit-scrollbar-thumb': {
                          background: 'rgba(37, 99, 235, 0.5)',
                          borderRadius: '8px',
                          transition: 'background 0.3s ease',
                        },
                        '&::-webkit-scrollbar-thumb:hover': {
                          background: 'rgba(37, 99, 235, 0.8)',
                        },
                        // Firefox scrollbar styling
                        scrollbarWidth: 'thin',
                        scrollbarColor: 'rgba(37, 99, 235, 0.5) rgba(229, 231, 235, 0.3)',
                      }}
                    >
                      {additionalInfo.length > 0 ? (
                        additionalInfo.map((info, index) => (
                          <Card
                            key={index}
                            onClick={() => info.link && window.open(info.link, '_blank', 'noopener')}
                            sx={{
                              backgroundColor: '#F9FAFB',
                              boxShadow: '0 2px 8px rgba(0, 0, 0, 0.06)',
                              borderRadius: 3,
                              cursor: info.link ? 'pointer' : 'default',
                              transition: 'transform 0.3s, box-shadow 0.3s',
                              '&:hover': {
                                transform: info.link ? 'translateY(-4px)' : 'none',
                                boxShadow: info.link ? '0 4px 12px rgba(0, 0, 0, 0.1)' : '0 2px 8px rgba(0, 0, 0, 0.06)',
                              },
                              minHeight: '90px',
                            }}
                          >
                            <CardContent sx={{ p: 2.5 }}>
                              <Typography
                                variant="body1"
                                sx={{
                                  color: '#1F2937',
                                  fontFamily: '"Lora", serif',
                                  lineHeight: 1.6,
                                  fontSize: '0.95rem',
                                }}
                              >
                                {info.description || 'No description available.'}
                              </Typography>
                            </CardContent>
                          </Card>
                        ))
                      ) : (
                        <Typography
                          variant="body1"
                          sx={{
                            color: '#6B7280',
                            fontFamily: '"Lora", serif',
                            p: 2.5,
                            fontStyle: 'italic',
                          }}
                        >
                          No additional information available.
                        </Typography>
                      )}
                    </Box>
                  </CardContent>
                </Card>
              </Box>
            </Fade>
          </Box>
        </Box>
      </Fade>
    </Box>
  );
};

export default OverviewLaunchesSection;