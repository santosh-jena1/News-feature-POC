import React from 'react';
import { Container, Box } from '@mui/material';
import Header from './components/Header';
import LaunchesSection from './sections/LaunchesSection';
import AIInnovationsSection from './sections/AIInnovationsSection';
import Sidebar from './components/Sidebar';
import Footer from './components/Footer';
import OverviewLaunchesSection from './sections/OverviewLaunchesSection';
// import GoogleTranslate from './components/GoogleTranslate';

const App = () => {
  return (
    <Box sx={{ backgroundColor: '#F9FAFB' }}>
      <Header />
      {/* <GoogleTranslate /> */}
      <Container sx={{ py: 1 }}> {/* Reduced from py: 2 to py: 1 */}
        <Box sx={{ display: 'flex', flexDirection: { xs: 'column', lg: 'row' }, gap: 1 }}> {/* Reduced gap from 4 to 3 */}
          <Box sx={{ flex: 2 }}>
            <OverviewLaunchesSection />
            <LaunchesSection />
            <AIInnovationsSection />
          </Box>
          <Sidebar />
        </Box>
      </Container>
      <Footer />
    </Box>
  );
};

export default App;