import React from 'react';
import { Card, CardMedia, CardContent, Typography, Button } from '@mui/material';

const NewsCard = ({ article }) => {
  const handleReadMoreClick = () => {
    window.open(article.link, '_blank', 'noopener,noreferrer');
  };

  return (
    <Card className="news-card" sx={{ borderRadius: '8px', overflow: 'hidden', width: '100%' }}>
      <CardMedia
        component="img"
        height="160"
        image={article.image || 'https://via.placeholder.com/400x200?text=No+Image'}
        alt={article.title}
        sx={{ objectFit: 'cover' }}
      />
      <CardContent sx={{ p: 2 }}>
        <Typography variant="caption" className="category-label">
          {article.category || (article.link.includes('ai') ? 'AI Innovations' : 'Launches')}
        </Typography>
        <Typography variant="h6" className="font-serif" sx={{ color: '#1E40AF', mt: 1, mb: 1, fontWeight: '600' }}>
          {article.title}
        </Typography>
        <Typography variant="body2" sx={{ color: '#4B5563', mb: 1 }}>
          {article.snippet}
        </Typography>
        <Button
          component="span" // prevents rendering as <a>
          variant="text"
          sx={{ color: '#2563EB', textTransform: 'none', fontSize: '0.875rem', p: 0 }}
          onClick={handleReadMoreClick}
        >
          Read More
        </Button>
      </CardContent>
    </Card>
  );
};

export default NewsCard;
