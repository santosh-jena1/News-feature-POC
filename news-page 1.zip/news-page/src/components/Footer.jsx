import React from 'react';
import { Box, Typography, Link as MuiLink } from '@mui/material';
import msLogo from '../assets/images/ms-logo.png';

const Footer = () => {
  return (
    <Box sx={{ bgcolor: '#1E40AF', color: 'white', py: 4, textAlign: 'center' }}>
      <Box sx={{ maxWidth: '1200px', mx: 'auto', px: 2 }}>
        <img src={msLogo} alt="Maruti Suzuki Logo" style={{ height: '40px', marginBottom: '16px' }} />
        <Typography variant="h6" className="font-serif" sx={{ mb: 1 }}>
          Maruti Suzuki AutoTech News © 2025
        </Typography>
        <Typography variant="body2" sx={{ mb: 2 }}>
          Your source for the latest in automotive innovation and AI technology.
        </Typography>
        <Box sx={{ display: 'flex', justifyContent: 'center', gap: 2 }}>
          <MuiLink href="#" underline="hover" sx={{ color: '#BFDBFE', fontSize: '0.875rem' }}>
            Contact Us
          </MuiLink>
          <MuiLink href="#" underline="hover" sx={{ color: '#BFDBFE', fontSize: '0.875rem' }}>
            Privacy Policy
          </MuiLink>
          <MuiLink href="#" underline="hover" sx={{ color: '#BFDBFE', fontSize: '0.875rem' }}>
            Terms of Service
          </MuiLink>
        </Box>
      </Box>
    </Box>
  );
};

export default Footer;