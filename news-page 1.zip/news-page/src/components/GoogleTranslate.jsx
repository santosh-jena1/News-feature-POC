import React, { useEffect, useRef } from 'react';

function setCookie(name, value, days) {
  let expires = '';
  if (days) {
    const date = new Date();
    date.setTime(date.getTime() + days * 24 * 60 * 60 * 1000);
    expires = '; expires=' + date.toUTCString();
  }
  document.cookie = name + '=' + (value || '') + expires + '; path=/';
}

const GoogleTranslate = () => {
  const containerRef = useRef(null);

  useEffect(() => {
    window.googleTranslateElementInit = () => {
      if (
        window.google &&
        window.google.translate &&
        containerRef.current
      ) {
        containerRef.current.innerHTML = '';
        new window.google.translate.TranslateElement(
          {
            pageLanguage: 'en',
            layout: window.google.translate.TranslateElement.InlineLayout.SIMPLE,
            autoDisplay: false,
          },
          containerRef.current
        );
      }
    };

    if (
      !document.querySelector(
        'script[src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"]'
      )
    ) {
      const script = document.createElement('script');
      script.src = '//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
      script.async = true;
      document.body.appendChild(script);
    } else {
      if (window.googleTranslateElementInit) {
        window.googleTranslateElementInit();
      }
    }
  }, []);

  const translateTo = (lang) => {
    setCookie('googtrans', `/en/${lang}`, 1);
    setTimeout(() => window.location.reload(), 300);
  };

  const resetTranslation = () => {
    setCookie('googtrans', `/en/en`, 1);
    setTimeout(() => window.location.reload(), 300);
  };

  return (
    <>
      {/* Make this container visible but minimal */}
      <div ref={containerRef} style={{ width: 0, height: 0, overflow: 'hidden' }} />
      <div
        style={{
          position: 'fixed',
          bottom: 16,
          right: 16,
          zIndex: 10000,
          display: 'flex',
          flexDirection: 'column',
          gap: '8px',
          backgroundColor: '#fff',
          padding: '8px',
          borderRadius: '4px',
          boxShadow: '0 2px 6px rgba(0,0,0,0.2)',
        }}
      >
        <button
          onClick={() => translateTo('hi')}
          style={{
            padding: '6px 12px',
            borderRadius: '4px',
            border: '1px solid #2563EB',
            backgroundColor: '#2563EB',
            color: 'white',
            fontWeight: '600',
            cursor: 'pointer',
          }}
        >
          Translate to Hindi
        </button>
        <button
          onClick={() => translateTo('ja')}
          style={{
            padding: '6px 12px',
            borderRadius: '4px',
            border: '1px solid #2563EB',
            backgroundColor: '#2563EB',
            color: 'white',
            fontWeight: '600',
            cursor: 'pointer',
          }}
        >
          Translate to Japanese
        </button>
        <button
          onClick={resetTranslation}
          style={{
            padding: '6px 12px',
            borderRadius: '4px',
            border: '1px solid #999',
            backgroundColor: '#eee',
            color: '#333',
            fontWeight: '600',
            cursor: 'pointer',
          }}
        >
          Reset Translation
        </button>
      </div>
    </>
  );
};

export default GoogleTranslate;
