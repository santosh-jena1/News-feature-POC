import React from 'react';
import { AppBar, Toolbar, Box, Link as MuiLink } from '@mui/material';
import { Link } from 'react-scroll';
import msLogo from '../assets/images/ms-logo.png';

const Header = () => {
  return (
    <AppBar position="sticky" sx={{ bgcolor: 'white', boxShadow: '0 4px 6px rgba(0,0,0,0.1)' }}>
      <Toolbar sx={{ display: 'flex', justifyContent: 'space-between', px: 2 }}>
        <Box sx={{ display: 'flex', alignItems: 'center' }}>
          <img src={msLogo} alt="Maruti Suzuki Logo" style={{ height: 40, marginRight: 12 }} />
        </Box>
        <Box component="nav" sx={{ display: 'flex', gap: 4 }}>
          <MuiLink
            component={Link}
            to="launches"
            smooth={true}
            duration={500}
            underline="hover"
            sx={{ color: '#2563EB', fontWeight: 500, cursor: 'pointer' }}
          >
            Launches
          </MuiLink>
          <MuiLink
            component={Link}
            to="ai-innovations"
            smooth={true}
            duration={500}
            underline="hover"
            sx={{ color: '#2563EB', fontWeight: 500, cursor: 'pointer' }}
          >
            AI Innovations
          </MuiLink>
        </Box>
      </Toolbar>
    </AppBar>
  );
};

export default Header;
