import React from 'react';
import { Box, Typography, Button } from '@mui/material';
import { marutiSuzukiNews } from '../data/newsData';

const FeaturedBanner = () => {
  const featuredArticle = marutiSuzukiNews[0]; 

  return (
    <Box className="banner-img" sx={{ bgcolor: '#1E40AF', py: 4 }}>
      <Box sx={{ maxWidth: '1200px', mx: 'auto', px: 2 }}>
        <Typography variant="caption" className="category-label" sx={{ color: '#BFDBFE' }}>
          Featured
        </Typography>
        <Typography
          variant="h2"
          className="font-serif"
          sx={{ color: 'white', mt: 1, mb: 2, fontWeight: 'bold' }}
        >
          {featuredArticle.title}
        </Typography>
        <Typography
          variant="body1"
          sx={{ color: 'white', maxWidth: '600px', mb: 2 }}
        >
          {featuredArticle.snippet}
        </Typography>
        <Button
          variant="text"
          sx={{ color: '#BFDBFE', '&:hover': { color: 'white' }, textTransform: 'none' }}
          href={featuredArticle.link}
          target="_blank"
          rel="noopener noreferrer"
        >
          Read Full Story
        </Button>
      </Box>
    </Box>
  );
};

export default FeaturedBanner;