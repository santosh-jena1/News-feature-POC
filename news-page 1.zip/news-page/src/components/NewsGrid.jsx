import React from 'react';
import { Container, Grid } from '@mui/material';
import NewsCard from './NewsCardComponent';
import { launches } from './newsData';

const NewsCardGrid = () => {
  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <Grid container spacing={2} sx={{ display: 'grid', gridTemplateColumns: { sm: 'repeat(2, 1fr)' } }}>
        {launches.map((article) => (
          <Grid item xs={12} sm={6} md={6} key={article.id} sx={{ display: 'flex' }}>
            <NewsCard article={article} />
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

export default NewsCardGrid;