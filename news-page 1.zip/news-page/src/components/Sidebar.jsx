import React from 'react';
import { Box, Typography, Link as MuiLink } from '@mui/material';
import { trending } from '../data/newsData';

const Sidebar = () => {
  return (
    <Box sx={{ flex: 1, p: 2 }}>
      <Typography variant="h5" className="font-serif" sx={{ color: '#1E40AF', fontWeight: 'bold', mb: 2 }}>
        Trending Stories
      </Typography>
      <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {trending.map((article, index) => (
          <Box
            key={index}
            className="sidebar-card"
            sx={{ bgcolor: 'white', p: 2, borderRadius: '4px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)' }}
          >
            <Typography variant="h6" className="font-serif" sx={{ color: '#1E40AF', fontWeight: '600', mb: 1 }}>
              {article.title}
            </Typography>
            <Typography variant="body2" sx={{ color: '#4B5563', mb: 1 }}>
              {article.snippet}
            </Typography>
            <MuiLink
              href={article.link}
              underline="hover"
              sx={{ color: '#2563EB', fontSize: '0.875rem' }}
              target="_blank"
              rel="noopener noreferrer"
            >
              Read More
            </MuiLink>
          </Box>
        ))}
      </Box>
    </Box>
  );
};

export default Sidebar;